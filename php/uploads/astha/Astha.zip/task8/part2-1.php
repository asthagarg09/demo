<?php
$input = "";
$input_err = "";
if($_SERVER["REQUEST_METHOD"] == "POST"){
    if(empty($_POST["input"])) {
        $input_err = "required field";
    } 
    else {
        $input= test_input($_POST["input"]);
        $regex = '/^[a-fA-F0-9]{2}$/'; 
        $input = test_input($_POST["input"]);
        if (!preg_match($regex, $input)) {
            $input_err = "Insert correct pattern";
        }
    }

}

function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
  }
?>

<!doctype html>
<head>
<title>Page Title</title>
</head>
<body>
<form method="post" action="part2-1.php">
    Input: <input type="text" name= "input"> <?php echo $input_err; ?>
    <button type="submit">Submit</button>
    <?php echo $input; ?>
</form>
</body>
</html>
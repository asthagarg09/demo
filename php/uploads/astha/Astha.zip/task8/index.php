<?php

$email = $phone = $website = $ip = $sin = "";
$email_err = $phone_err = $website_err = $ip_err = $sin_err = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST["email"])) {
        $email_err = "required field";
      } else {
        $regex = '/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/'; 
        $email = test_input($_POST["email"]);
        if (!preg_match($regex, $email)) {
          $email_err = "Insert correct pattern";
        }
      }

    if(empty($_POST["phone_number"])) {
        $phone_err = "required field";
      } else {
        $regex = '/^[0-9]{3}-[0-9]{3}-[0-9]{4}$/'; 
        $phone = test_input($_POST["phone_number"]);
        if (!preg_match($regex, $phone)) {
          $phone_err = "Insert correct pattern";
        }
    }
    if(empty($_POST["website"])) {
        $website_err = "required field";
      } else {
        $regex = '/\b(?:(?:https?|ftp):\/\/)?(www.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i'; 
        $website = test_input($_POST["website"]);
        if (!preg_match($regex, $website)) {
          $website_err = "Insert correct pattern";
        }
    }
    if(empty($_POST["ip_address"])) {
        $ip_err = "required field";
      } else {
        $regex = '/^[0-9]{3}.[0-9]{3}.[0-9]{3}.[0-9]{3}$/'; 
        $ip = test_input($_POST["ip_address"]);
        if (!preg_match($regex, $ip)) {
          $ip_err = "Insert correct pattern";
        }
    }
    if(empty($_POST["sin_number"])) {
        $sin_err = "required field";
      } else {
        $regex = '/^[0-9]{3}\s[0-9]{3}\s[0-9]{3}$/';  
        $sin = test_input($_POST["sin_number"]);
        if (!preg_match($regex, $sin)) {
          $sin_err = "Insert correct pattern";
        }
    }
    if(empty($email_err) && empty($phone_err) && empty($website_err) && empty($ip_err) && empty($sin_err)){
        echo "Form submitted";
    }
}


function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

?>
<!DOCTYPE html>
<html>
<head>
<title>Page Title</title>
</head>
<body>
<form action="index.php" method="post">
Email <input type="email" name="email"> <?php echo $email_err; ?><br>
Phone number <input type="text" name="phone_number"><?php echo $phone_err; ?><br>
Website <input type="text" name="website"><?php echo $website_err; ?><br>
IP address <input type="text" name="ip_address"><?php echo $ip_err; ?><br>
Sin <input type="text" name="sin_number"><?php echo $sin_err; ?><br>
<button type="submit">Submit</button>
</form>
</body>
</html>


<?php

$name = $age = $password = $city = $country = "";
$name_err = $age_err = $password_err = $city_err = $country_err = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (empty($_POST["userName"])) {
        $name_err = "required field";
      } else {
        $name = filter_var($_POST['userName'], FILTER_SANITIZE_STRING);
        //$name = test_input($_POST["userName"]);
        /*$regex = '/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/'; 
        $email = test_input($_POST["email"]);
        if (!preg_match($regex, $email)) {
          $email_err = "Insert correct pattern";
        }*/
      }

    if(empty($_POST["age"])) {
        $age_err = "required field";
      } else {
        $age= filter_var($_POST['age'], FILTER_SANITIZE_STRING);
        if (filter_var($age, FILTER_VALIDATE_INT, array("options" => array("min_range"=>18, "max_range"=>120))) === false) {
            $age_err = "Age value is not within the legal range";
            $age = "";
        } 
          /*
        $regex = '/^[0-9]{3}-[0-9]{3}-[0-9]{4}$/'; 
        $phone = test_input($_POST["phone_number"]);
        if (!preg_match($regex, $phone)) {
          $phone_err = "Insert correct pattern";
        }
        */
    }
    if(empty($_POST["password"])) {
        $password_err = "required field";
      } else {
        $password = filter_var($_POST['password'], FILTER_SANITIZE_STRING);
        if(strlen(trim($password)) > 6)
        {
            $password_err = "Password must not be longer than 6 characters";
            $password = "";
        }
        
          /*
        $regex = '/\b(?:(?:https?|ftp):\/\/)?(www.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i'; 
        $website = test_input($_POST["website"]);
        if (!preg_match($regex, $website)) {
          $website_err = "Insert correct pattern";
        }*/
    }
    if(empty($_POST["city"])) {
        $city_err = "required field";
      } else {
        $city = filter_var($_POST['city'], FILTER_SANITIZE_STRING);
        /*
        $regex = '/^[0-9]{3}.[0-9]{3}.[0-9]{3}.[0-9]{3}$/'; 
        $ip = test_input($_POST["ip_address"]);
        if (!preg_match($regex, $ip)) {
          $ip_err = "Insert correct pattern";
        }*/
    }
    if(empty($_POST["country"])) {
        $country_err = "required field";
      } else {
        $country = filter_var($_POST['country'], FILTER_SANITIZE_STRING);  
        /*
        $regex = '/^[0-9]{3}\s[0-9]{3}\s[0-9]{3}$/';  
        $sin = test_input($_POST["sin_number"]);
        if (!preg_match($regex, $sin)) {
          $sin_err = "Insert correct pattern";
        }*/
    }
    if(empty($name_err) && empty($age_err) && empty($password_err) && empty($city_err) && empty($country_err)){
        echo "Form submitted";
    }
}


function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

?>
<!DOCTYPE html>
<html>
<head>
<title>Page Title</title>
</head>
<body>
<form action="submit.php" method="post">
User Name <input type="text" name="userName"> <?php echo $name_err; ?><br>
Age <input type="text" name="age"><?php echo $age_err; ?><br>
Password <input type="password" name="password"><?php echo $password_err; ?><br>
City <input type="text" name="city"><?php echo $city_err; ?><br>
Country <input type="text" name="country"><?php echo $country_err; ?><br>
<button type="submit">Submit</button>
<?php echo $name; ?>
<?php echo $age; ?>
<?php echo $password; ?>
<?php echo $city; ?>
<?php echo $country; ?>
</form>
</body>
</html>

